# Daily Build Log

Format: one entry per day. Fill in **Done** and **Blocker** before committing — don't leave a day blank.

---

## Week 1

### Day 1 — Repo setup + benchmark data
- [x] GitHub repo created with folder structure
- [x] Decision made: benchmark-only (no WRDS/panel access) — using agency-published matrices directly as working data
- [x] Benchmark matrices saved: `data/moodys_corporate_{1y,3y,10y}.csv` and `data/sp_corporate_{1y,3y,10y}.csv`
- **Done:** Sourced both agencies' Form NRSRO Exhibit 1 filings from SEC EDGAR, extracted Corporate Issuers transition/default tables via pdfplumber (position-aligned, not flattened text), validated all 6 matrices row-sum to ~100% (98-102% range, matching source PDF rounding). Two-agency benchmark in place before Day 2 even starts.
- **Blocker:** None. Note for Day 5 validation: Moody's and S&P use different notch scales (Aaa/Aa1/Aa2... vs AAA/AA+/AA...) — need a crosswalk table before direct comparison.

### Day 2 — Raw ratings data (or skip if benchmark-only)
- [ ] `data/ratings_panel.csv` cleaned to (issuer_id, date, rating)
- [ ] OR: documented decision to proceed benchmark-only in this file
- **Done:**
- **Blocker:**

### Day 3 — Cohort counting logic
- [ ] `src/build_transition_matrix.py` counts migrations by rating category
- [ ] Script runs and prints a raw count matrix
- **Done:**
- **Blocker:**

### Day 4 — Convert to probabilities
- [ ] Rows normalized to sum to 1.00
- [ ] Default state enforced as absorbing
- **Done:**
- **Blocker:**

### Day 5 — Validation against Moody's/S&P
- [ ] `outputs/validation_comparison.png` — side-by-side heatmap or table
- [ ] `notes/validation_writeup.md` — 3-5 sentences on any gaps
- **Done:**
- **Blocker:**

---

## Week 2

_(to be filled in after Week 1 wraps)_
