# Credit Migration / Transition Matrix Model

Cohort-method Markov chain model of corporate bond rating transitions, benchmarked against published Moody's/S&P transition studies and stress-tested under recession vs. expansion macro regimes.

FIM 601 | NC State University | Vedashree Teli

## Structure

- `data/` — benchmark transition matrices (Moody's + S&P, 1/3/10-year, Corporate Issuers)
  - `data/raw/` — source PDFs (SEC Form NRSRO Exhibit 1 filings, both agencies)
- `src/` — extraction and matrix construction code
- `outputs/` — charts, comparison plots, results
- `notes/` — validation write-ups
- `DAILY_LOG.md` — day-by-day build log

## Data sources

Both benchmark matrices are the agencies' own published cohort-method transition/default rate
tables, filed annually with the SEC as Exhibit 1 to Form NRSRO:

- Moody's: https://www.sec.gov/Archives/edgar/data/1698547/000119312526133970/d113944dex99e1nrsro.pdf
- S&P: https://www.sec.gov/Archives/edgar/data/1650548/000165054826000001/Ex1_Mar2026.pdf

Extracted with `src/extract_matrices.py` (pdfplumber, position-aligned table extraction — not
OCR/text-flattening, so blank cells are correctly read as 0%).

## Status

Day 1 done — benchmark data sourced and extracted (Moody's + S&P, Corporate Issuers, 1/3/10-year).
Next — cohort-method matrix construction (if panel data available) or direct use of these
benchmark matrices as the working baseline.

## Methodology

See project proposal (`Credit_Transition_Matrix_Proposal.docx`) for full methodology, timeline, and references.
